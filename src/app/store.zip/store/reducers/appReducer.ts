import {ACTION_LOGOUT, ACTION_LOGIN} from '../actions/appActions';

export interface AppReducerState {
    login: boolean,
    user?: string,
}

const initialState: AppReducerState = {
    login: false,
    user: "GUEST"
}
export function reducer(state = initialState, action) {
    switch(action.type) {
        case ACTION_LOGOUT:
            return {
                ...state,
                login: false,
                user: action.payload
            }
            break;
        case ACTION_LOGIN:
            return {
                ...state,
                login: true,
                user: action.payload
            }
    }
    return state;
}