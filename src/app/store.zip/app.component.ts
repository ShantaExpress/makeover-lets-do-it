import { Component } from '@angular/core';
import { UserService } from './user.service';
import { ACTION_LOGIN, ACTION_LOGOUT } from './store/actions/appActions';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  title = 'shanta-apparel';
  constructor(private user: UserService) {

  }

  login() {
    this.user.updateState({
      type: ACTION_LOGIN,
      payload: 'Ujjal Bhaskar'
    });
  }

  logout() {
    this.user.updateState({
      type: ACTION_LOGOUT,
      payload: ''
    });
  }
}
