import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private store: Store<any>) { }

  getAllState() {
    return this.store.select('appReducer');
  }

  updateState(obj) {
    this.store.select('appReducer');
    this.store.dispatch({
      type: obj.type,
      payload: obj.payload
    })
  }
}
